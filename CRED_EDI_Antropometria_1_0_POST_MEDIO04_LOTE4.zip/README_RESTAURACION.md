# README DE RESTAURACIÓN — CRED & EDI Antropometría 1.0 (Post MEDIO-04 Lote 4)

## 1. Descripción del Paquete
Este archivo (`CRED_EDI_Antropometria_1_0_POST_MEDIO04_LOTE4.zip`) contiene el respaldo íntegro y verificable del código fuente, recursos clínicos/gráficos, configuración Gradle y suite de 208 pruebas automatizadas del proyecto **CRED & EDI Antropometría 1.0**, en su estado exacto posterior al cierre técnico de **MEDIO-04 (Lotes 1, 2, 2B, 3 y 4)**.

## 2. Requisitos del Entorno de Compilación
- **Gradle:** `9.3.1` (configurado en `gradle/wrapper/gradle-wrapper.properties`)
- **Android Gradle Plugin (AGP):** `9.1.1` (definido en `gradle/libs.versions.toml`)
- **Kotlin:** `2.2.10` / **KSP:** `2.3.5`
- **JDK para el daemon de Gradle:** JDK `21` (Eclipse Adoptium 21 LTS o compatible; `compileOptions` usa `JavaVersion.VERSION_11`)
- **Android SDK:**
  - `compileSdk`: API `36` (`release(36) { minorApiLevel = 1 }`)
  - `targetSdk`: API `36`
  - `minSdk`: API `24`

## 3. Exclusiones de Seguridad Aplicadas
Por políticas de seguridad del respaldo:
- Se **excluyeron** los archivos de firma `debug.keystore` y `debug.keystore.base64`, así como cualquier archivo `.env` con secretos o llaves privadas.
- Se **excluyeron** directorios regenerables de compilación y cachés (`.gradle/`, `.kotlin/`, `build/`, `app/build/`, `.build-outputs/`).
- No existe ningún dato personal de pacientes en el proyecto.

### Nota sobre `debug.keystore` al compilar APK Debug
`app/build.gradle.kts` declara `signingConfigs.getByName("debugConfig")` apuntando a `${rootDir}/debug.keystore` (contraseña `android`, alias `androiddebugkey`).
- Para ejecutar pruebas unitarias y Robolectric (`testDebugUnitTest`) **no** se requiere `debug.keystore`.
- Para ensamblar el APK (`assembleDebug`) en un entorno nuevo, genere primero un keystore de depuración estándar en la raíz del proyecto con el siguiente comando:
  ```bash
  keytool -genkeypair -v \
    -keystore debug.keystore \
    -storepass android \
    -alias androiddebugkey \
    -keypass android \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=Android Debug,O=Android,C=US"
  ```

## 4. Pasos para Extraer y Verificar Integridad
1. Extraer el archivo ZIP en un directorio limpio:
   ```bash
   mkdir cred_edi_restored
   unzip CRED_EDI_Antropometria_1_0_POST_MEDIO04_LOTE4.zip -d cred_edi_restored
   cd cred_edi_restored
   ```
2. Verificar la integridad criptográfica SHA-256 de todos los archivos incluidos:
   ```bash
   sha256sum -c MANIFEST_SHA256.txt
   ```
   Todos los archivos deben reportar `OK`.

## 5. Abrir en Android Studio y Compilar
1. En **Android Studio**, seleccione **File > Open...** y elija la carpeta extraída (`cred_edi_restored`).
2. Asegúrese de que Android Studio configure el **Gradle JDK 21** y el **Android SDK (API 36)** en *Settings > Build, Execution, Deployment > Build Tools > Gradle*.
3. Ejecute **Sync Project with Gradle Files**.
4. Para compilar desde terminal (con Gradle 9.3.1 instalado o generando el wrapper con `gradle wrapper`):
   ```bash
   gradle :app:compileDebugKotlin :app:compileDebugUnitTestKotlin
   ```
5. Para ejecutar la suite completa de **208 pruebas automatizadas (Unit + Robolectric)**:
   ```bash
   gradle :app:testDebugUnitTest --rerun-tasks
   ```
   Los 20 reportes XML se generarán en `app/build/test-results/testDebugUnitTest/`.
